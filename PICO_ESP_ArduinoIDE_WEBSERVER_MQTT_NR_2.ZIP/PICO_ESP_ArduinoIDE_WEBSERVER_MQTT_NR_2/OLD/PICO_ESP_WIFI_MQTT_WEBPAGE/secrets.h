// secrets.h
#define SECRET_SSID "<SSID>"
#define SECRET_PASSWORD "<SSIDPASSWORD>"
// that is a combi project for PICO W and ESP32S3 boards
// code for PICO and compiler switches for ESP
#define REV "v2.0.0"
// Web-Server
#ifdef ESP32
#define FIXIP {192,168,1,216}
#else
#define FIXIP {192,168,1,215}
#endif

#define PORT 1234

#define useFakeAuth 0
#define SECRET_URLHASH "/AaAweNoaS8FR7F75YNUmowR7ivxtPR0WG57Cqb4bN1c=/"
// http://192.168.1.215:1234/AaAweNoaS8FR7F75YNUmowR7ivxtPR0WG57Cqb4bN1c=/

// MQTT
#define SECRET_MQTT_REMOTE 0
// REMOTE BROKER
#define SECRET_RMQTTBROKER "XXX.hivemq.cloud"
#define SECRET_RMQTTUSER "upPICOW"
#define SECRET_RMQTTPW "pPICOW"
// RPI4 Mosquitto ( with MQTT_REMOTE=False )
#define SECRET_LMQTTBROKER "192.168.1.104"  // 192,168,1,104 if use IPAddress mqtt_broker(192,168,1,104);
#define SECRET_LMQTTUSER "uPICOW"
#define SECRET_LMQTTPW "pPICOW"
#define MQTT_port 1883

#ifdef ESP32
#define sTOPIC "ESP32S3/D216/status"
#define dTOPIC "ESP32S3/D216/data"
#define rTOPIC "ESP32S3/D216/set" //'LED TOGGLE' R0 R1 R2 R3
#define fTOPIC "ESP32S3/D216/fdata" //___________ 1 sec reads A0
#define MQTT_CLIENTID "ESP32S3 D216"
#define MQTT_STATUS "ESP32S3 ArduinoIDE"
#else
#define sTOPIC "PICOW/D215/status"
#define dTOPIC "PICOW/D215/data"
#define rTOPIC "PICOW/D215/set" //'LED TOGGLE' R0 R1 R2 R3
#define fTOPIC "PICOW/D215/fdata" //___________ 1 sec reads A0
#define MQTT_CLIENTID "PICOW D215"
#define MQTT_STATUS "PICO W ArduinoIDE"
#endif
// device HOME page auto adjust on device
#ifdef ESP32
#define HTML_TITLE "ESP32S3 N16R8"
#define HTML_HEADER "ESPRESSIF ESP32-S3"
#else
#define HTML_TITLE "PICO W"
#define HTML_HEADER "Raspberry Pi Pico W"
#endif
