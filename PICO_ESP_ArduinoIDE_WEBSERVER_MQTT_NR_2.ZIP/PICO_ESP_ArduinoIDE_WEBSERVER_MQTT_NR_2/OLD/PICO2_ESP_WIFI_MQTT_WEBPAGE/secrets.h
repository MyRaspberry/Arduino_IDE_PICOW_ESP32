// secrets.h
#define use4RELAY  // disable with //

#define SECRET_SSID "<SSID>"
#define SECRET_PASSWORD "<SSIDPASSWORD>"
// that is a combi project for PICO W and ESP32S3 boards
// code for PICO and compiler switches for ESP
//add a switch for the PICO W2 .217 /D217/ and more info use // to disable this
// 4-relay board as option

#define usePICOW2

#define REV "v2.3.0"
// Web-Server
#ifdef ESP32
#define FIXIP {192,168,1,216}
#else

#ifdef usePICOW2
#define FIXIP {192,168,1,217}
#else
#define FIXIP {192,168,1,215}
#endif

#endif

#define PORT 1234

#define useFakeAuth 0
#define SECRET_URLHASH "/AaAweNoaS8FR7F75YNUmowR7ivxtPR0WG57Cqb4bN1c=/"
// http://192.168.1.215:1234/AaAweNoaS8FR7F75YNUmowR7ivxtPR0WG57Cqb4bN1c=/

// MQTT
#define SECRET_MQTT_REMOTE 0
// REMOTE BROKER
#define SECRET_RMQTTBROKER "XXXXXX.hivemq.cloud"
#define SECRET_RMQTTUSER "uPICOW"
#define SECRET_RMQTTPW "pPICOW"
// RPI4 Mosquitto ( with MQTT_REMOTE=False )
#define SECRET_LMQTTBROKER "192.168.1.104"  // 192,168,1,104 if use IPAddress mqtt_broker(192,168,1,104);
#define SECRET_LMQTTUSER "uPICOW"
#define SECRET_LMQTTPW "pPICOW"
#define MQTT_port 1883

#ifdef ESP32
#define sTOPIC "ESP32S3/D216/status"
#define dTOPIC "ESP32S3/D216/data"
#define rTOPIC "ESP32S3/D216/set" //'LED TOGGLE' R0 R1 R2 R3
#define fTOPIC "ESP32S3/D216/fdata" //___________ 1 sec reads A0
#define MQTT_CLIENTID "ESP32S3 D216"
#define MQTT_STATUS "ESP32S3 ArduinoIDE"
#else

#ifdef usePICOW2
#define sTOPIC "PICOW/D217/status"
#define dTOPIC "PICOW/D217/data"
#define rTOPIC "PICOW/D217/set" //'LED TOGGLE' R0 R1 R2 R3
#define fTOPIC "PICOW/D217/fdata" //___________ 1 sec reads A0
#define MQTT_CLIENTID "PICO2W D217"
#define MQTT_STATUS "PICO 2W ArduinoIDE"
#else
#define sTOPIC "PICOW/D215/status"
#define dTOPIC "PICOW/D215/data"
#define rTOPIC "PICOW/D215/set" //'LED TOGGLE' R0 R1 R2 R3
#define fTOPIC "PICOW/D215/fdata" //___________ 1 sec reads A0
#define MQTT_CLIENTID "PICOW D215"
#define MQTT_STATUS "PICO W ArduinoIDE"
#endif

#endif
// device HOME page auto adjust on device
#ifdef ESP32
#define HTML_TITLE "ESP32S3 N16R8"
#define HTML_HEADER "ESPRESSIF ESP32-S3"
#else

#ifdef usePICOW2
#define HTML_TITLE "PICO 2W"
#define HTML_HEADER "Raspberry Pi Pico 2W"

#else
#define HTML_TITLE "PICO W"
#define HTML_HEADER "Raspberry Pi Pico W"

#endif

#endif
