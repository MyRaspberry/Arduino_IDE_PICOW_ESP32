// settings.h
// ip format is tricky, array of bytes so IPAddress thisip(FIXIP) understands it

#ifndef STASSID
#define STASSID "<SSID>"
#define STAPSK "<SSIDPASSWORD>"
#define REV "v1.1.0"
#define FIXIP {192,168,1,222}
#define PORT 2222
// optional pwm output to test osci jumper pins 
#define TESTPWM 1

#endif
